package com.example.automotive_api

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AutomotiveApiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
