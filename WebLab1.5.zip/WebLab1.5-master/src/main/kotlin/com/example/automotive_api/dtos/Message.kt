package com.example.automotive_api.dtos

data class Message(val message: String)